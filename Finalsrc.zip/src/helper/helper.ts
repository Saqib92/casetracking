export class globalData{
	public static serviceUrl = "https://developervikram.com/demoapp-we/api/";
	public static imagesUrl = "https://developervikram.com/demoapp-we/public/images/";

}